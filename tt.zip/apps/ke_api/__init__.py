"""Knowledge Engine API - FastAPI REST endpoints."""

from apps.ke_api.main import app

__all__ = ["app"]

"""Knowledge Engine CLI application."""

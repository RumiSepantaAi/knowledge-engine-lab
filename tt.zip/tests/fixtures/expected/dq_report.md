# Data Quality Report

## Summary

- Files processed: 1
- Total rows: 6
- Unique terms: 11

## Counts by Level

| Level | Unique Values |
|-------|---------------|
| L1    |             2 |
| L2    |             4 |
| L3    |             4 |
| L4    |            11 |

## Issues Found

### Missing Levels

None found.

### Duplicate Terms

- "PostgreSQL" appears 2x

### Empty Terms

None found.

### Suspicious Split Candidates

None found.

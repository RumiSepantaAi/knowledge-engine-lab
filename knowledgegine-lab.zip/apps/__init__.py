"""Knowledge Engine CLI - Interactive workflow for knowledge management."""
